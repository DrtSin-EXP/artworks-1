# Kernel Flashing Script for Devices Having Vbmeta Appeneded to Boot #

## What this is ##
---------------------------------------------------------------------
Due to Certain Devies having, Vbmeta Appended to Boot, They were'nt able to use AnyKernel Script !! 

This Script Kinda Makes Work of Such Devices Easier !

### How to use ###

Here are some useful notes to using this tool !

1. First Of All Apply This [***Patch***](https://github.com/Maanush2004/android_device_realme_RMX1821/blob/lineage-18.1-rmui/patches/build/make/0001-build-Add-option-to-append-vbmeta-image-to-boot-imag.patch) in Build/make Directory Of your ROM Source ! 

2. Now Compile the Bootimage

3. Now do ``` git clone https://github.com/techyminati/ManyKernel.git ```

4. Copy boot.img to ```ManyKernel``` folder & zip

5. Congrats Now You Can Flash On Devices which have Vbmeta Appended On Boot


#### Why Is This Needed ? ####

- Some Devices Launched with Android 9 Aint Have vbmeta partition , but when they got a major update ( A10) OEM's append vbmeta to Boot Image, Making Stuffs Tough
  So This Simple Script it useful for Such Devices ( In Our Case, We Encountered realme 3/3i which has same, vbmeta being appended to boot !

#### Credits and Thanks to People Who Helped me ####

 * [***Maanush***](https://github.com/Maanush2004) - For Creating the Awesome Vbmeta Patch & Enlightening About How Vbmeta is Appended to Boot
 * [***Osmosis***](https://github.com/osm0sis) - For his AnyKernel3 as Reference ( Tho ManyKernel isn't a Copy Of that, But Osmosis's AnyKernel May be helpful in future ManyKernel Implementations xd )
 * Everyone Who helped me in a way or other in Creating this Script


Enjoy & Thanks
